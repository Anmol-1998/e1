
export default {
  orange: '#f7a253',
  red: '#f75353',
  green: '#27AE60',
  blue: '#5264AE',
  lightBlue: '#7082C2',
  grey: '#5f5f5f',
  darkGrey: '#3C3C3C',
  black: '#1C1C1C',
  white: '#FFFFFF',
  transparentGrey: 'rgba(95, 95, 95, 0.5)',
  lightGrey: '#BBBBBB'
}
