import TorrentsTab from './torrents'
import FilesTab from './files'

export { TorrentsTab, FilesTab }